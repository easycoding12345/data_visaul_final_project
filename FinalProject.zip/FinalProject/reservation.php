<!DOCTYPE html>
<html lang="en">
<head>
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="main.css">
      <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css' />
          <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Reservation</title>
</head>
<body>
    <nav>
    <div class="wrapper" >
      <div class="logo"><a href="main.html"><img class = "logo" src="Images/rl-logo-gold.png" style="width: 200px"> </a></div>
      <input type="radio" name="slider" id="menu-btn">
      <input type="radio" name="slider" id="close-btn">
      <ul class="nav-links">
        <label for="close-btn" class="btn close-btn"><i class="fas fa-times"></i></label>
              <li><a href="main.html">Home</a></li>
        <li><a href="reservation.php">Reservation</a></li>
        <li>
          <a href="#" class="desktop-item">Interior</a>
          <input type="checkbox" id="showDrop">
          <label for="showDrop" class="mobile-item">Interior</label>
          <ul class="drop-menu">
            <li><a href="interior.php">Bedrooms</a></li>
            <li><a href="interior.php">Events Spaces</a></li>
            <li><a href="interior.php">Dining Rooms</a></li>
          </ul>
        </li>
        <li>
          <a href="#" class="desktop-item">Exterior</a>
          <input type="checkbox" id="showDrop2">
          <label for="showDrop2" class="mobile-item">Exterior</label>
          <ul class="drop-menu2">
            <li><a href="exterior.html">Swimming Pools</a></li>
            <li><a href="exterior.html">Bar</a></li>
            <li><a href="exterior.html">Wedding Halls</a></li>
          </ul>
        </li>
        <li>
          <a href="#" class="desktop-item">More</a>
          <input type="checkbox" id="showMega">
          <label for="showMega" class="mobile-item">More</label>
          <div class="mega-box">
            <div class="content">
              <div class="row">
                 <img src="Images/maxresdefault.jpg" alt=""> 
              </div>
            <div class="row">
                <h2>Resturants</h2>
                <ul class="mega-links">
                  <li><a href="#">Menu</a></li>
                  <li><a href="#">Dining Sites</a></li>
                  <li><a href="#">Privacy Seal</a></li>
                  <li><a href="#">Website design</a></li>
                </ul>
              </div>
              <div class="row">
                <h2>Contact Us</h2>
                <ul class="mega-links">
                  <li><a href="contact.html">Business Email</a></li>
                  <li><a href="contact.html">Phone</a></li>
                  <li><a href="contact.html">Mobile</a></li>
                  <li><a href="contact.html">WhatsApp</a></li>
                </ul>
              </div>
              <div class="row">
                <h2>Membership</h2>
                <ul class="mega-links">
                  <li><a href="login.html">Sign In</a></li>
                  <li><a href="register.html">Create an Account</a></li>
                  <li><a href="cart.php">Cart</a></li>
                  <li><a href="feedback.html">Feedback</a></li>
                </ul>
              </div>
            </div>
          </div>
        </li>
      </ul>
      <label for="menu-btn" class="btn menu-btn"><i class="fas fa-bars"></i></label>
    </div>
  </nav>
  <br>
    <br>
      <br>
      
      <div class="container">
          <div class="row" style="background: #a39161;">
              <div class="cols-sm">
                  <a class="nav-link" href="cart.php"><i  class="fas fa-shopping-cart fa-3x" style="color: black;"></i> <span style="height: 20px;" id="cart-item" class="badge badge-danger"></span></a>
              </div>
          </div>
      </div>
      
  <div class="container">
    <div id="message"></div>
    <div class="row mt-2  pb-3">
      <?php
  			include 'db.php';
  			$result = mysqli_query($conn,"SELECT * FROM `room`");
  			while ($row = mysqli_fetch_assoc($result)){
  		?>
      <div class="col-sm-12 col-md-6 col-lg-6  mb-3">
        <div class="card-deck">
          <div class="card p-2 border-secondary mb-2">
            <img src="<?php echo $row["room_image"]; ?>" class="card-img-top" style = "height: 400px; width = 800px;">
            <div class="card-body p-1">
              <h4 class="card-title text-center text-info"><?php echo $row["room_name"]; ?></h4>
              <h5 class="card-text text-center text-black"><i class="fas fa-dollar-sign"></i>&nbsp;&nbsp;<?php echo  number_format($row['room_price']); ?>/-</h5>
            </div>
             <div class="card-footer p-1">
              <form action="" class="form-submit">
                <div class="row p-2">
                  <div class="col-md-6 py-1 pl-4">
                    <b>Number : </b>
                  </div>
                  <div class="col-md-6">
                    <input type="number" class="form-control pqty" class= "pqty" >
                  </div>
                </div>
                <input type="hidden" class="pid" value="<?php echo $row['id'] ?>">
                <input type="hidden" class="pname" value="<?php echo $row['room_name'] ?>">
                <input type="hidden" class="pprice" value="<?php echo $row['room_price'] ?>">
                <input type="hidden" class="pimage" value="<?php echo $row['room_image'] ?>">
                <input type="hidden" class="pcode" value="<?php echo $row['room_code'] ?>">
                <button style=" background: black;" class="btn btn-info btn-block addItemBtn"><i class="fas fa-cart-plus"></i>&nbsp;&nbsp;Add to
                  cart</button>
              </form>
              </div>
          </div>
        </div>
      </div>
          <?php } mysqli_close($conn); ?>
    </div>
  </div>
      <div class="footer1" style="background: #011b31; padding: 30px;">
        <div class="container" >
           <div class="row" >
               <div class="col-sm-3"> 
        <a href="main.html" class="fmain">HOME</a> <br> 
        <a href="reservation.php" class="fmain">RESERVATION</a>
               </div>
               <div class="col-sm-3">
                   <a class="fmain" href="interior.html" >INTERIOR</a> <br>
                   <a href="interior.php">Bedrooms</a><br>
                   <a href="interior.php">Events Spaces</a> <br>
                   <a href="interior.php">Dining Rooms</a>
               </div>
                  <div class="col-sm-3">
                   <a class="fmain" href="exterior.html" >EXTERIOR</a> <br> 
                   <a href="#">Swimming Pool</a><br>
                   <a href="#">Bar</a> <br>
                   <a href="#">Wedding Halls</a>
               </div>
                 <div class="col-sm-3">
                   <a class="fmain" href="#" >MORE</a> <br> 
                   <a href="#">Resturant</a><br>
                   <a href="contact.html">Contact Us</a> <br>
                   <a href="register.html">Membership</a>
               </div>
           </div>
          <div class="row">
              <div class="col-sm" style="font-size: 1rem; color: white;">
                   Find Us on Social Media
              </div>
          </div>
           <div class="row">
            <div class="col-sm">
                <a href="https://www.facebook.com/AUAfghanistan"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                <a href="https://www.instagram.com/auafofficial/"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                <a href="https://www.linkedin.com/company/auaf/"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                  <a href="https://twitter.com/AUAfghanistan?lang=en"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                  <a href="#" ><i class="fa fa-whatsapp" aria-hidden="true"></i></a>
             </div>
               
           </div>
           <div  style="font-size: 0.8rem; color: white; text-align: center;">
               © 2021 REMOTE LANDS. ALL RIGHTS RESERVED
           </div>

        </div>
        
    </div>
     
     
    
    <!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js'></script>

  <script type="text/javascript">
  $(document).ready(function() {

    // Send product details in the server
    $(".addItemBtn").click(function(e) {
      e.preventDefault();
      var $form = $(this).closest(".form-submit");
      var pid = $form.find(".pid").val();
      var pname = $form.find(".pname").val();
      var pprice = $form.find(".pprice").val();
      var pimage = $form.find(".pimage").val();
      var pcode = $form.find(".pcode").val();

      var pqty = $form.find(".pqty").val();

      $.ajax({
        url: 'action.php',
        method: 'post',
        data: {
          pid: pid,
          pname: pname,
          pprice: pprice,
          pqty: pqty,
          pimage: pimage,
          pcode: pcode
        },
        success: function(response) {
          $("#message").html(response);
          window.scrollTo(0, 0);
          load_cart_item_number();
        }
      });
    });

    // Load total no.of items added in the cart and display in the navbar
    load_cart_item_number();

    function load_cart_item_number() {
      $.ajax({
        url: 'action.php',
        method: 'get',
        data: {
          cartItem: "cart_item"
        },
        success: function(response) {
          $("#cart-item").html(response);
        }
      });
    }
  });
  </script>

</body>
</html>