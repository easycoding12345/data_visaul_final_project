<?php 
session_start();

$dbserver="localhost"; 
$dbuser="root";
$dbpass="";
$dbname="dbHMS";

$connect=mysqli_connect($dbserver,$dbuser,$dbpass,$dbname) or die("unable to connect");


if(!empty($_POST['q1'])) {
$q1= $_POST['q1'];
}
if(!empty($_POST['q2'])) {
$q2=$_POST['q2'];
}
if(!empty($_POST['q3'])) {
$q3=$_POST['q3'];
}
$username= $_POST['uname'];
$pass=$_POST['pswd'];
$comment=$_POST['comment'];


$s= "SELECT * FROM `customer` WHERE username= '$username' && password= '$pass'";

$result= mysqli_query($connect,$s);

$num= mysqli_num_rows($result);

if($num== 1){
    	$reg="INSERT INTO `feedback`(`answer1`, `answer2`, `answer3`, `comment`, `password`, `username`) VALUES ('$q1', '$q2', '$q3', '$comment', '$pass','$username')";
	mysqli_query($connect,$reg);
    echo '<script>alert("Feedback successfully recorded!")</script>'; 
}
else{
    	echo '<script>alert("You are not a registered user!")</script>'; 

    
}




 ?>