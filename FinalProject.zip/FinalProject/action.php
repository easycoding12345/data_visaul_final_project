 <?php


    session_start();
    require 'db.php';
    if(isset($_POST['pid'])){  //getting the ajax request from client send to server
        
        $pid = $_POST['pid'];
        $pname = $_POST['pname'];
        $pprice = $_POST['pprice'];
        $pimage = $_POST['pimage'];
        $pcode = $_POST['pcode'];
        $pqty = $_POST['pqty'];
        $total = intval($pprice) * intval($pqty) ;
 
        $stmt = $conn->prepare("SELECT roomCode FROM cart WHERE roomCode=?");
        $stmt->bind_param("s",$pcode);
        $stmt->execute();
        $res = $stmt->get_result();
        $r = $res->fetch_assoc();
        $code = $r['roomCode'] ?? '';
 
        if(!$code){
            if($pqty!="" and $pqty!=0 and $pqty>0){
                            $query = $conn->prepare("INSERT INTO cart (roomName,roomPrice,roomImage,qty,totalPrice,roomCode) VALUES (?,?,?,?,?,?)");
            $query->bind_param("sssiss",$pname,$pprice,$pimage,$pqty,$total,$pcode);
            $query->execute();
            echo '<div class="alert alert-success alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>Room added to your cart!</strong>
                        </div>';
            }
            else{
                echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>Please specify the no of rooms!</strong>
                        </div>';
            }

        }
        else{
            echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>Room already added to your cart!</strong>
                        </div>';
        } 
}
	// Get no.of items available in the cart table
	if (isset($_GET['cartItem']) && isset($_GET['cartItem']) == 'cart_item') {
		$stmt = $conn->prepare('SELECT * FROM cart');
		$stmt->execute();
		$stmt->store_result();
		$rows = $stmt->num_rows;
  
		echo $rows;
	  }
  
	  // Remove single items from cart
	  if (isset($_GET['remove'])) {
		$id = $_GET['remove'];
  
		$stmt = $conn->prepare('DELETE FROM cart WHERE cartID=?');
		$stmt->bind_param('i',$id);
		$stmt->execute();
  
		$_SESSION['showAlert'] = 'block';
		$_SESSION['message'] = 'Item removed from the cart!';
		header('location:cart.php');
	  }
  
	  // Remove all items at once from cart
	  if (isset($_GET['clear'])) {
		$stmt = $conn->prepare('DELETE FROM cart');
		$stmt->execute();
		$_SESSION['showAlert'] = 'block';
		$_SESSION['message'] = 'All Item removed from the cart!';
		header('location:cart.php');
	  }

  
	  // Set total price of the product in the cart table
	  if (isset($_POST['qty'])) {
		$qty = $_POST['qty'];
		$pid = $_POST['pid'];
		$pprice = $_POST['pprice'];
  
		$tprice = $qty * $pprice;
  
		$stmt = $conn->prepare('UPDATE cart SET qty=?, total_price=? WHERE id=?');
		$stmt->bind_param('isi',$qty,$tprice,$pid);
		$stmt->execute();
	  }
  
	  // Checkout and save customer info in the orders table
	  if (isset($_POST['action']) && isset($_POST['action']) == 'order') {
		$username = $_POST['name'];
		$products = $_POST['products'];
		$grand_total = $_POST['grand_total'];
		$pmode = $_POST['pmode'];
		$data = '';
        $pass=$_POST['password'];
        $checkin = $_POST['checkindate'];
          $checkout = $_POST['checkoutdate'];

        $s= "SELECT * FROM `customer` WHERE username= '$username' && password= '$pass'";

        $result= mysqli_query($conn,$s);

        $num= mysqli_num_rows($result);

        if($num== 1){
            		$stmt = $conn->prepare('INSERT INTO reservation (username,pMode,rooms,amountPaid,password,check_in_date, check_out_date)VALUES(?,?,?,?,?,?,?)');
		$stmt->bind_param('sssssdd',$username,$pmode,$products,$grand_total, $pass, $checkin, $checkout );
		$stmt->execute();
		$stmt2 = $conn->prepare('DELETE FROM cart');
		$stmt2->execute();
		$data .= '<div class="text-center">
								  <h1 class="display-4 mt-2 text-danger">Thank You!</h1>
								  <h2 class="text-success">Your Order Placed Successfully!</h2>
								  <h4 class="bg-danger text-light rounded p-2">Rooms Reserved : ' . $products . '</h4>
								  <h4>Your Username : ' . $username . '</h4>
								  <h4>Your Password : ' . $pass . '</h4>
								  <h4>Total Amount Paid : ' . number_format($grand_total,2) . '</h4>
								  <h4>Payment Mode : ' . $pmode . '</h4>
							</div>';
		echo $data;

        }
          else{
             echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>You are not a registered customer! please sign up!</strong>
                        </div>';
          }

	  }

?>