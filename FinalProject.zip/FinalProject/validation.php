<?php 
session_start();

$dbserver="localhost"; 
$dbuser="root";
$dbpass="";
$dbname="dbHMS";

$connect=mysqli_connect($dbserver,$dbuser,$dbpass,$dbname) or die("unable to connect");

$username= $_POST['username'];
$pass=$_POST['password'];


$s= "SELECT * FROM `customer` WHERE username= '$username' && password= '$pass'";

$result= mysqli_query($connect,$s);

$num= mysqli_num_rows($result);

if($num== 1){
	$_SESSION['username']= $username;
	header('location:main.html');
}
else if($username =='Admin' && $pass == 'Admin'){
$_SESSION['username']= $username;	
header('location:admin.php');

}
else{

    echo '<script>alert("User Does Not Exist! Please Sign Up.")</script>'; 
//		header('location:register.html');
}











 ?>