<?php 
session_start();

$dbserver="localhost"; 
$dbuser="root";
$dbpass="";
$dbname="dbHMS";

$connect=mysqli_connect($dbserver,$dbuser,$dbpass,$dbname) or die("unable to connect");

$fname= $_POST['FirstName'];
$lname=$_POST['LastName'];
$username= $_POST['usernameRegis'];
$phone=$_POST['phoneRegis'];
$email=$_POST['emailRegis'];
$pass=$_POST['passwordRegis'];


$s= "SELECT * FROM `customer` WHERE username= '$username'";

$result= mysqli_query($connect,$s);

$num= mysqli_num_rows($result);

if($num== 1){
	echo '<script>alert("Username Already Taken!")</script>'; 
}
else{

	$reg="INSERT INTO `customer`(`fname`, `lname`, `username`, `phone`, `email`, `password`) VALUES ('$fname', '$lname', '$username', '$phone', '$email','$pass')";
	mysqli_query($connect,$reg);
    header('location:login.html');
    echo '<script>alert("Registration Successful! Please login.")</script>'; 
    
}




 ?>