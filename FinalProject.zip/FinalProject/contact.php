<?php 
session_start();

$dbserver="localhost"; 
$dbuser="root";
$dbpass="";
$dbname="dbHMS";

$connect=mysqli_connect($dbserver,$dbuser,$dbpass,$dbname) or die("unable to connect");

$fname= $_POST['fullname'];
$phone=$_POST['phone'];
$email=$_POST['email'];
$question=$_POST['question'];



	$reg="INSERT INTO `contact`(`name`, `phone`, `email`, `question`) VALUES ('$fname', '$phone', '$email','$question')";
	mysqli_query($connect,$reg);
    echo '<script>alert("Question successfully recorded! You will get your answer soon.")</script>'; 
    





 ?>