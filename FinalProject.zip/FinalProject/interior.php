
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Interior</title>
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        
        <style type="text/css">
            
.card {
	width: 500px;
	height: 450px;
	margin: 6% auto;
	border-radius: 8px;
	box-shadow: 0px 2px 6px rgba(0, 0, 0, 0.2), 0px 2px 6px rgba(0, 0, 0, 0.4);
	overflow: hidden;
}

#blur {
	background: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/225748/MD_background.png) no-repeat center center fixed;
	background-size: cover;
	width: 530px;
	height: 480px;
	position: relative;
	top: -15px;
	left: -15px;
	border-radius: 8px;
	-webkit-filter: blur(8px);
	-moz-filter: blur(8px);
	filter: blur(8px);
}

#color {
	background: rgba(255, 255, 255, .60);
	width: 530px;
	height: 480px;
}

#profile {
	cursor: grabbing;
	width: 500px;
	height: 450px;
	position: relative;
	top: -480px;
	border-radius: 8px;
}

.card img {
	width: 100%;
	height: 300px;
	position: relative;
	top: 0px;
    margin-top: 0px;

}



.card a {
	color: rgba(255, 255, 255, 1);
	transition: color 0.4s;
	text-decoration: none;
}
.card a:hover {
	color: rgba(255, 255, 255, .70);
	transition: color 0.4s; 
}

.info {
	text-align: center;
	margin: 0 auto;
	position: relative;
	top: 0px;
	background: rgba(38, 50, 56, 1);
	width: 32px;
	height: 32px;
	border-radius: 100px;
	background-position: center center;
	background-size: cover;
	transition: all 0.2s ease;
	z-index: 0;
}

.info.active {
	width: 100%;
	height: 50%;
	position: relative;
	top: -900%;
	background: rgba(38, 50, 56, 1);
	transition: width .1s ease, height .2s ease, top .2s ease, z-index .2s ease;
	z-index: 999;
}

.info i.block {
	color: rgba(255, 255, 255, .6);
	display: block;
}

.info .fa-info {
	padding: 8px;
	cursor: pointer;
	visibility: visible;
 opacity: 1;
	transition: visibility 0s, opacity 0.4s ease;
}

.info.active .fa-info {
	visibility: hidden;
 opacity: 0;
 transition: visibility 0s, opacity 0.4s ease;
}

.info .fa-angle-down {
	cursor: pointer;
	visibility: hidden;
}

.info.active .fa-angle-down {
	position: relative;
	margin: 0 auto;
	width: 24px;
	height: 24px;
	padding: 4px;
	visibility: visible;
	position: relative;
	top: 128px;
	animation-name: visible;
	animation-duration: 0.3s;
}

@keyframes visible {
	0% {
		opacity: 0;
	}
	100% {
		opacity: 1;
	}
}

.info p {
	color: rgba(255, 255, 255, 1);
	font-family: 'Roboto Condensed', sans-serif;
	font-size: 18px;
	line-height: 110%;
	font-weight: 400;
	text-align: center;
	padding: 24px;
	position: relative;
	top: 144px;
	visibility: hidden;
}

.info.active p {
	visibility: visible;
	animation-name: entrance-first;
	animation-duration: 0.4s;
}

.info .link {
	visibility: hidden;
	margin: 24px 24px 0px 24px;
	padding: 16px 4px 4px 4px;
	cursor: pointer;

}

.info.active .link {
	visibility: visible;
	animation-name: entrance-second;
	animation-duration: 0.5s;
}

@keyframes entrance-first {
	0% {
		top: 200px;
	}
	100% {
		top: 144px;
	}
}

@keyframes entrance-second {
	0% {
		top: 200px;
	}
	100% {
		top: 144px;
	}
}
    </style>
</head>
<body>
   
    <nav>
    <div class="wrapper" >
      <div class="logo"><a href="main.html"><img class = "logo" src="Images/rl-logo-gold.png" style="width: 200px"> </a></div>
      <input type="radio" name="slider" id="menu-btn">
      <input type="radio" name="slider" id="close-btn">
      <ul class="nav-links">
        <label for="close-btn" class="btn close-btn"><i class="fas fa-times"></i></label>
        <li><a href="main.html">Home</a></li>
        <li><a href="reservation.php">Reservation</a></li>
        <li>
          <a href="#" class="desktop-item">Interior</a>
          <input type="checkbox" id="showDrop">
          <label for="showDrop" class="mobile-item">Interior</label>
          <ul class="drop-menu">
            <li><a href="interior.php">Bedrooms</a></li>
            <li><a href="interior.php">Events Spaces</a></li>
            <li><a href="interior.php">Dining Rooms</a></li>
          </ul>
        </li>
        <li>
          <a href="#" class="desktop-item">Exterior</a>
          <input type="checkbox" id="showDrop2">
          <label for="showDrop2" class="mobile-item">Exterior</label>
          <ul class="drop-menu2">
            <li><a href="exterior.html">Swimming Pools</a></li>
            <li><a href="exterior.html">Bar</a></li>
            <li><a href="exterior.html">Wedding Halls</a></li>
          </ul>
        </li>
        <li>
          <a href="#" class="desktop-item">More</a>
          <input type="checkbox" id="showMega">
          <label for="showMega" class="mobile-item">More</label>
          <div class="mega-box">
            <div class="content">
              <div class="row">
                 <img src="Images/maxresdefault.jpg" alt=""> 
              </div>
            <div class="row">
                <h2>Resturants</h2>
                <ul class="mega-links">
                  <li><a href="#">Menu</a></li>
                  <li><a href="#">Dining Sites</a></li>
                  <li><a href="#">Privacy Seal</a></li>
                  <li><a href="#">Website design</a></li>
                </ul>
              </div>
              <div class="row">
                <h2>Contact Us</h2>
                <ul class="mega-links">
                  <li><a href="contact.html">Business Email</a></li>
                  <li><a href="contact.html">Phone</a></li>
                  <li><a href="contact.html">Mobile</a></li>
                  <li><a href="contact.html">WhatsApp</a></li>
                </ul>
              </div>
              <div class="row">
                <h2>Membership</h2>
                <ul class="mega-links">
                  <li><a href="login.html">Sign In</a></li>
                  <li><a href="register.html">Create an Account</a></li>
                  <li><a href="cart.php">Cart</a></li>
                  <li><a href="feedback.html">Feedback</a></li>
                </ul>
              </div>
            </div>
          </div>
        </li>
      </ul>
      <label for="menu-btn" class="btn menu-btn"><i class="fas fa-bars"></i></label>
    </div>
  </nav>
<br>
<br>
<br>
<br>
<div class="container">
             <div class="row" style="background: #a39161;">
              <div class="cols-sm">
                  <a class="nav-link" href="cart.php"><i  class="fas fa-shopping-cart fa-3x" style="color: black;"></i> <span style="height: 20px;" id="cart-item" class="badge badge-danger"></span></a>
              </div>
          </div>
    <div id="message"></div>
    <div class="row mt-4  pb-3">
      
    <?php
    include_once("db.php");
   $sql = "SELECT id, room_name, room_price, room_image, room_capacity, room_availability, room_code  FROM room";
			$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));			
			while( $record = mysqli_fetch_assoc($resultset) ) {
			?>

            <div class="col-sm-12 col-md-6 col-lg-4" style="margin-bottom: 3%;">
            <div class="flip-card">
              <div class="flip-card-inner">
                <div class="flip-card-front">
                  <img src="<?php echo $record['room_image']; ?>" alt="couple" style="width:100%;height:100%;">             

                </div>

                <div class="flip-card-back" style="text-align: center; padding: 20px;">
                  
                  <p>Room Capacity:<br> <?php echo $record['room_capacity']; ?></p>
                <p>Room Availability:<br> <?php echo $record['room_availability']; ?></p>
                <p>Room Code:<br> <?php echo $record['room_code']; ?></p>
     
               
                <div class="card-footer p-1">
              <form action="" class="form-submit">
                               <div class="row p-2">
                  <div class="col-md-6 py-1 pl-4">
                    <b>Number : </b>
                  </div>
                  <div class="col-md-6">
                    <input type="number" class="form-control pqty" class= "pqty" >
                  </div>
                </div>
                <input type="hidden" class="pid" value="<?php echo $record['id'] ?>">
                <input type="hidden" class="pname" value="<?php echo $record['room_name'] ?>">
                <input type="hidden" class="pprice" value="<?php echo $record['room_price'] ?>">
                <input type="hidden" class="pimage" value="<?php echo $record['room_image'] ?>">
                <input type="hidden" class="pcode" value="<?php echo $record['room_code'] ?>">
                <button style=" background: black;" class="btn btn-info btn-block addItemBtn"><i class="fas fa-cart-plus"></i>&nbsp;&nbsp;Add to
                  cart</button>
              </form>
              </div>
                </div>
              </div>
               <div class="front-title" style="font-size: 1.5 rem; background: #032c4f; text-align: center; color: white; width: 100%;"><?php echo $record['room_name']; ?></div>  
            </div> 
            </div>
         <?php } mysqli_close($conn); ?> 
    </div>
    </div>          
          
  
          
          
          
          
    <div class="footer1" style="background: #011b31; padding: 30px;">
        <div class="container" >
           <div class="row" >
               <div class="col-sm-3"> 
        <a href="main.html" class="fmain">HOME</a> <br> 
        <a href="reservation.php" class="fmain">RESERVATION</a>
               </div>
               <div class="col-sm-3">
                   <a class="fmain" href="interior.html" >INTERIOR</a> <br>
                   <a href="interior.php">Bedrooms</a><br>
                   <a href="#">Events Spaces</a> <br>
                   <a href="#">Dining Rooms</a>
               </div>
                  <div class="col-sm-3">
                   <a class="fmain" href="exterior.html" >EXTERIOR</a> <br> 
                   <a href="#">Swimming Pool</a><br>
                   <a href="#">Bar</a> <br>
                   <a href="#">Wedding Halls</a>
               </div>
                 <div class="col-sm-3">
                   <a class="fmain" href="#" >MORE</a> <br> 
                   <a href="#">Resturant</a><br>
                   <a href="contact.html">Contact Us</a> <br>
                   <a href="register.html">Membership</a>
               </div>
           </div>
          <div class="row">
              <div class="col-sm" style="font-size: 1rem; color: white;">
                   Find Us on Social Media
              </div>
          </div>
           <div class="row">
            <div class="col-sm">
                <a href="https://www.facebook.com/AUAfghanistan"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                <a href="https://www.instagram.com/auafofficial/"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                <a href="https://www.linkedin.com/company/auaf/"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                  <a href="https://twitter.com/AUAfghanistan?lang=en"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                  <a href="#" ><i class="fa fa-whatsapp" aria-hidden="true"></i></a>
             </div>
               
           </div>
           <div  style="font-size: 0.8rem; color: white; text-align: center;">
               © 2021 REMOTE LANDS. ALL RIGHTS RESERVED
           </div>

        </div>
        
    </div>
    
        <!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js'></script>
    
  <script type="text/javascript">
  $(document).ready(function() {

    // Send product details in the server
    $(".addItemBtn").click(function(e) {
      e.preventDefault();
      var $form = $(this).closest(".form-submit");
      var pid = $form.find(".pid").val();
      var pname = $form.find(".pname").val();
      var pprice = $form.find(".pprice").val();
      var pimage = $form.find(".pimage").val();
      var pcode = $form.find(".pcode").val();

      var pqty = $form.find(".pqty").val();

      $.ajax({
        url: 'action.php',
        method: 'post',
        data: {
          pid: pid,
          pname: pname,
          pprice: pprice,
          pqty: pqty,
          pimage: pimage,
          pcode: pcode
        },
        success: function(response) {
          $("#message").html(response);
          window.scrollTo(0, 0);
          load_cart_item_number();
        }
      });
    });

    // Load total no.of items added in the cart and display in the navbar
    load_cart_item_number();

    function load_cart_item_number() {
      $.ajax({
        url: 'action.php',
        method: 'get',
        data: {
          cartItem: "cart_item"
        },
        success: function(response) {
          $("#cart-item").html(response);
        }
      });
    }
  });
  </script>
    
    </body>
     
    