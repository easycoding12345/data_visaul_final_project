<?php 



session_start();
if(!isset($_SESSION['username'])){
  header('location:login.html');
}
    
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin
    </title>
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
              <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css' />

  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css' />
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  
</head>
<body>
   
     <nav>
    <div class="wrapper" >
      <div class="logo"><a href="main.html"><img class = "logo" src="Images/rl-logo-gold.png" style="width: 200px"> </a></div>
      <input type="radio" name="slider" id="menu-btn">
      <input type="radio" name="slider" id="close-btn">
      <ul class="nav-links">
        <label for="close-btn" class="btn close-btn"><i class="fas fa-times"></i></label>
        <li><a href="admin.php#customers">Customers</a></li>
        <li><a href="admin.php#reservations">Reservations</a></li>
         <li><a href="admin.php#feedback">Messages</a></li>
        <li><a href="admin.php#messages">Feedback</a></li>
        <li><a href="admin.php#rooms">Rooms</a></li>
      </ul>
      <label for="menu-btn" class="btn menu-btn"><i class="fas fa-bars"></i></label>
    </div>
  </nav>

    <br>
     <br>
     <br>
 <br>
     
     <section id="customers"  >

        <div class="container mb-4">
            <div class="row" class="row justify-content-center mb-5">
                <div class="col-lg-12 col-md-10 col-sm-6">
                    <div class="table-responsive mt-2">
          <table class="table table-bordered table-striped text-center">
            <thead>
              <tr>
                <td colspan="8">
                  <h4 class="text-center text-info m-0">REGISTERED CUSTOMERS</h4>
                  <a href="createcust.php" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Add New Customer</a>
                </td>
              </tr>
              <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Username</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Password</th>
                <th>
                  <a href="actionadmin.php?clear=all" class="badge-danger badge p-1" onclick="return confirm('Are you sure want to clear your cart?');"><i class="fas fa-trash"></i>&nbsp;&nbsp;Clear List</a>
                </th>
              </tr>
            </thead>
            <tbody>
              <?php
                require 'db.php';
                $result = mysqli_query($conn,"SELECT * FROM `customer` order by customerid");
  			   while ($row = mysqli_fetch_assoc($result)){
                
              ?>
              <tr>
                <td><?php echo $row['customerid'] ?></td>
                <td><?php echo $row['fname'] ?></td>
                <td><?php echo $row['lname'] ?></td>
                <td><?php echo $row['username'] ?></td>
                <td>
                  <?php echo $row['phone'] ?>
                </td>
                <td><?php echo $row['email'] ?></td>
               
                <td>
                  <?php echo $row['password'] ?>
                </td>
                <td>
                             <a href="update.php?id=<?php echo $row['customerid'] ?>" class="mr-3" title="Update Record" data-toggle="tooltip"><span class="fa fa-edit"></span></a>
                                <a href="actionadmin.php?remove=<?php echo $row['customerid'] ?>" title="Delete Record" data-toggle="tooltip"><span class="fa fa-trash"></span></a>
                </td>
              </tr>
              
               <?php } mysqli_close($conn); ?>
            
            </tbody>
          </table>
        </div>
         
                </div>
            </div>
        </div>
         
     </section> 
      
     <section id="reservations" >

        <div class="container mb-4">
            <div class="row" class="row justify-content-center mb-5">
                <div class="col-lg-12 col-md-10 col-sm-6">
                    <div class="table-responsive mt-2">
          <table class="table table-bordered table-striped text-center">
            <thead>
              <tr>
                <td colspan="9">
                  <h4 class="text-center text-info m-0">Reservations</h4>
                  <a href="createres.php" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Reserve a Room</a>
                </td>
              </tr>
              <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Payment Mode</th>
                <th>Rooms</th>
                <th>Amount Paid</th>
                <th>Password</th>
                <th>Check-in Date</th>
                <th>Check-out Date</th>
                <th>
                  <a href="actionadmin.php?clear2=all" class="badge-danger badge p-1" onclick="return confirm('Are you sure want to clear your cart?');"><i class="fas fa-trash"></i>&nbsp;&nbsp;Clear List</a>
                </th>
              </tr>
            </thead>
            <tbody>
              <?php
                require 'db.php';
                $result = mysqli_query($conn,"SELECT * FROM `reservation` order by resID");
  			   while ($row = mysqli_fetch_assoc($result)){
                
              ?>
              <tr>
                <td><?php echo $row['resID'] ?></td>
                <td><?php echo $row['username'] ?></td>
                <td><?php echo $row['pMode'] ?></td>
                <td><?php echo $row['rooms'] ?></td>
                <td>
                  <?php echo $row['amountPaid'] ?>
                </td>
                <td><?php echo $row['password'] ?></td>
               
                <td>
                  <?php echo $row['check_in_date'] ?>
                </td>
                      <td>
                  <?php echo $row['check_out_date'] ?>
                </td>
                <td>
<!--                             <a href="updateres.php?id=<?php echo $row['resID'] ?>" class="mr-3" title="Update Record" data-toggle="tooltip"><span class="fa fa-edit"></span></a>-->
                                <a href="actionadmin.php?remove2=<?php echo $row['resID'] ?>" title="Delete Record" data-toggle="tooltip"><span class="fa fa-trash"></span></a>
                </td>
              </tr>
              
               <?php } mysqli_close($conn); ?>
            
            </tbody>
          </table>
        </div>
                </div>
            </div>
        </div>
         
     </section> 
      
           <section id="feedback" >

        <div class="container"  class="mb-4">
            <div class="row" class="row justify-content-center mb-5">
                <div class="col-lg-12 col-md-10 col-sm-6">
                    <div class="table-responsive mt-2">
          <table class="table table-bordered table-striped text-center">
            <thead>
              <tr>
                <td colspan="8">
                  <h4 class="text-center text-info m-0">Customers Feedback</h4>
                </td>
              </tr>
              <tr>
                <th>ID</th>
                <th>Staff Behavior</th>
                <th>Room Service</th>
                <th>Food</th>
                <th>Comment</th>
                <th>Username</th>
                <th>Password</th>
                <th>
                  <a href="actionadmin.php?clear3=all" class="badge-danger badge p-1" onclick="return confirm('Are you sure want to clear all feedback?');"><i class="fas fa-trash"></i>&nbsp;&nbsp;Clear List</a>
                </th>
              </tr>
            </thead>
            <tbody>
              <?php
                require 'db.php';
                $result = mysqli_query($conn,"SELECT * FROM `feedback` order by feedID");
  			   while ($row = mysqli_fetch_assoc($result)){
                
              ?>
              <tr>
                <td><?php echo $row['feedID'] ?></td>
                <td><?php echo $row['answer1'] ?></td>
                <td><?php echo $row['answer2'] ?></td>
                <td><?php echo $row['answer3'] ?></td>
                <td>
                  <?php echo $row['comment'] ?>
                </td>
                <td><?php echo $row['username'] ?></td>
               
                <td>
                  <?php echo $row['password'] ?>
                </td>
                <td>
    
                     <a href="actionadmin.php?remove3=<?php echo $row['feedID'] ?>"  data-toggle="tooltip"><span class="fa fa-trash"></span></a>
                </td>
              </tr>
              
               <?php } mysqli_close($conn); ?>
            
            </tbody>
          </table>
        </div>
         
                </div>
            </div>
        </div>
     </section> 
     
     
       <section id="messages" >

        <div class="container mb-4">
            <div class="row" class="row justify-content-center mb-5">
                <div class="col-lg-12 col-md-10 col-sm-6">
                    <div class="table-responsive mt-2">
          <table class="table table-bordered table-striped text-center">
            <thead>
              <tr>
                <td colspan="6">
                  <h4 class="text-center text-info m-0">Customers Messages</h4>
                </td>
              </tr>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Question</th>

                <th>
                  <a href="actionadmin.php?clear4=all" class="badge-danger badge p-1" onclick="return confirm('Are you sure want to clear all messages?');"><i class="fas fa-trash"></i>&nbsp;&nbsp;Clear List</a>
                </th>
              </tr>
            </thead>
            <tbody>
              <?php
                require 'db.php';
                $result = mysqli_query($conn,"SELECT * FROM `contact` order by contactID");
  			   while ($row = mysqli_fetch_assoc($result)){
                
              ?>
              <tr>
                <td><?php echo $row['contactID'] ?></td>
                <td><?php echo $row['name'] ?></td>
                <td><?php echo $row['phone'] ?></td>
                <td><?php echo $row['email'] ?></td>
                <td>
                  <?php echo $row['question'] ?>
                </td>
                <td>
    
                     <a href="actionadmin.php?remove4=<?php echo $row['contactID'] ?>"  data-toggle="tooltip" ><span class="fa fa-trash"></span></a>
                </td>
              </tr>
              
               <?php } mysqli_close($conn); ?>
            
            </tbody>
          </table>
        </div>
         
                </div>
            </div>
        </div>
         
     </section> 
      
               
     <section id="rooms"  >

        <div class="container mb-4">
            <div class="row" class="row justify-content-center mb-5">
                <div class="col-lg-12 col-md-10 col-sm-6">
                    <div class="table-responsive mt-2">
          <table class="table table-bordered table-striped text-center">
            <thead>
              <tr>
                <td colspan="9">
                  <h4 class="text-center text-info m-0">Rooms</h4>
                  <a href="createroom.php" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Add New Room</a>
                </td>
              </tr>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Image</th>
                <th>Capacity</th>
                <th>Availability</th>
                <th>Code</th>
                <th>
                  <a href="actionadmin.php?clear5=all" class="badge-danger badge p-1" onclick="return confirm('Are you sure want to clear all the rooms?');"><i class="fas fa-trash"></i>&nbsp;&nbsp;Clear List</a>
                </th>
              </tr>
            </thead>
            <tbody>
              <?php
                require 'db.php';
                $result = mysqli_query($conn,"SELECT * FROM `room` order by id");
  			   while ($row = mysqli_fetch_assoc($result)){
                
              ?>
              <tr>
                <td><?php echo $row['id'] ?></td>
                <td><?php echo $row['room_name'] ?></td>
                <td><?php echo $row['room_price'] ?></td>
                <td><?php echo $row['room_qty'] ?></td>
                <td>
                 <img src="<?php echo $row['room_image'] ?>" class="img-fluid img-thumbnail" style = "width: 150px; height:100px;">
                  
                </td>
                <td><?php echo $row['room_capacity'] ?></td>
               
                <td>
                  <?php echo $row['room_availability'] ?>
                </td>
             <td>
                  <?php echo $row['room_code'] ?>
                </td>
                <td>
<!--                             <a href="update.php?id=<?php echo $row['id'] ?>" class="mr-3" title="Update Record" data-toggle="tooltip"><span class="fa fa-edit"></span></a>-->
                                <a href="actionadmin.php?remove5=<?php echo $row['id'] ?>" title="Delete Record" data-toggle="tooltip"><span class="fa fa-trash"></span></a>
                </td>
              </tr>
              
               <?php } mysqli_close($conn); ?>
            
            </tbody>
          </table>
        </div>
         
                </div>
            </div>
        </div>
         
     </section> 
      
      
              
        
                   
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>   
            
                      
</body>
</html>