<?php
// Include config file
require_once "db.php";
 

 if(isset($_POST['id'])&& !empty($_POST["id"])){ 
        $custid= $_POST['custid'];
        $fname= $_POST['fname'];
        $lname=$_POST['lname'];
        $username= $_POST['uname'];
        $phone=$_POST['phone'];
        $email=$_POST['email'];
        $pass=$_POST['pass'];
            
        $sql = "UPDATE customer SET fname= '$fname', lname= '$lname', username= '$username', phone= '$phone', email= '$email', password='$pass'  WHERE customerid= '$custid' ";
          
        $result= mysqli_query($conn,$sql);
     
        if($result){
            echo "Record Updated!";
            header('location:admin.php');
        }
     else{
         echo mysqli_error($conn);
     }
            
        mysqli_close($conn);
    }

 else{
    // Check existence of id parameter before processing further
     if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
        // Get URL parameter
        $id =  trim($_GET["id"]);

         
         
        $sql = "SELECT * FROM customer WHERE customerid = '$id' ";
        $result= mysqli_query($conn,$sql);
         if($result){
            $num= mysqli_num_rows($result);

            if($num== 1){
            
                    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    
                    $custid = $row["customerid"];
                    $fname = $row["fname"];
                    $lname = $row["lname"];
                    $username = $row["username"];
                    $phone = $row["phone"];
                    $email = $row["email"];
                    $pass = $row["password"];
    
                } else{
                    echo mysqli_error($conn);
                }
                
             
         }
         else{
             echo mysqli_error($conn);
         }
            
            } 
        }
        
        // Close connection

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Record</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="mt-5">Update Record</h2>
                    <p>Please edit the input values and submit to update the customer record.</p>
                    
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        <div class="form-group">
                            <label>Customer ID</label>
                            <input type="text" name="custid" class="form-control" value="<?php echo $custid; ?>">
                        </div>
                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" name="fname" class="form-control" value="<?php echo $fname; ?>">
                            <span class="invalid-feedback">Enter a valid name.</span>
                        </div>
                     <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" name="lname" class="form-control" value="<?php echo $lname; ?>">
                            <span class="invalid-feedback">Enter a valid name.</span>
                        </div>
                      <div class="form-group">
                            <label>Username</label>
                            <input type="text" name="uname" class="form-control" value="<?php echo $username; ?>">
                            <span class="invalid-feedback">Enter a valid name.</span>
                        </div>
                     <div class="form-group">
                            <label>Phone</label>
                            <input type="text" name="phone" class="form-control" value="<?php echo $phone; ?>">
                            <span class="invalid-feedback">Enter a valid phone no.</span>
                        </div>
                    <div class="form-group">
                            <label>Email</label>
                            <input type="text" name="email" class="form-control" value="<?php echo $email; ?>">
                            <span class="invalid-feedback">Enter a valid email.</span>
                        </div>
               <div class="form-group">
                            <label>Password</label>
                            <input type="text" name="pass" class="form-control" value="<?php echo $pass; ?>">
                            <span class="invalid-feedback">Enter a valid password.</span>
                        </div>
                        <input type="hidden" name="id" value="<?php echo $id; ?>"/>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-secondary ml-2">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>