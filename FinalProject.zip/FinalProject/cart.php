<?php
  session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main.css">

  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Cart</title>
          <link rel="stylesheet" href="main.css">
      <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css' />
          <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css' />

</head>

<body>
   <nav>
    <div class="wrapper" >
      <div class="logo"><a href="main.html"><img class = "logo" src="Images/rl-logo-gold.png" style="width: 200px"> </a></div>
      <input type="radio" name="slider" id="menu-btn">
      <input type="radio" name="slider" id="close-btn">
      <ul class="nav-links">
        <label for="close-btn" class="btn close-btn"><i class="fas fa-times"></i></label>
        <li><a href="main.html">Home</a></li>
        <li><a href="reservation.php">Reservation</a></li>
        <li>
          <a href="#" class="desktop-item">Interior</a>
          <input type="checkbox" id="showDrop">
          <label for="showDrop" class="mobile-item">Interior</label>
          <ul class="drop-menu">
            <li><a href="interior.php">Bedrooms</a></li>
            <li><a href="interior.php">Events Spaces</a></li>
            <li><a href="interior.php">Dining Rooms</a></li>
          </ul>
        </li>
        <li>
          <a href="#" class="desktop-item">Exterior</a>
          <input type="checkbox" id="showDrop2">
          <label for="showDrop2" class="mobile-item">Exterior</label>
          <ul class="drop-menu2">
            <li><a href="exterior.html">Swimming Pools</a></li>
            <li><a href="exterior.html">Bar</a></li>
            <li><a href="exterior.html">Wedding Halls</a></li>
          </ul>
        </li>
        <li>
          <a href="#" class="desktop-item">More</a>
          <input type="checkbox" id="showMega">
          <label for="showMega" class="mobile-item">More</label>
          <div class="mega-box">
            <div class="content">
              <div class="row">
                 <img src="Images/maxresdefault.jpg" alt=""> 
              </div>
            <div class="row">
                <h2>Resturants</h2>
                <ul class="mega-links">
                  <li><a href="#">Menu</a></li>
                  <li><a href="#">Dining Sites</a></li>
                  <li><a href="#">Privacy Seal</a></li>
                  <li><a href="#">Website design</a></li>
                </ul>
              </div>
              <div class="row">
                <h2>Contact Us</h2>
                <ul class="mega-links">
                  <li><a href="contact.html">Business Email</a></li>
                  <li><a href="contact.html">Phone</a></li>
                  <li><a href="contact.html">Mobile</a></li>
                  <li><a href="contact.html">WhatsApp</a></li>
                </ul>
              </div>
              <div class="row">
                <h2>Membership</h2>
                <ul class="mega-links">
                  <li><a href="login.html">Sign In</a></li>
                  <li><a href="register.html">Create an Account</a></li>
                  <li><a href="cart.php">Cart</a></li>
                  <li><a href="feedback.html">Feedback</a></li>
                </ul>
              </div>
            </div>
          </div>
        </li>
      </ul>
      <label for="menu-btn" class="btn menu-btn"><i class="fas fa-bars"></i></label>
    </div>
  </nav>
  <br>
  <br>
  <br>
  <br>

  <div class="container">
    <div class="row justify-content-center mb-5">
      <div class="col-lg-10">
        <div style="display:<?php if (isset($_SESSION['showAlert'])) {
            echo $_SESSION['showAlert'];
            } else {
                echo 'none';
            } unset($_SESSION['showAlert']); ?>" class="alert alert-success alert-dismissible mt-3">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong><?php if (isset($_SESSION['message'])) {
            echo $_SESSION['message'];
            } unset($_SESSION['showAlert']); ?></strong>
        </div>
        <div class="table-responsive mt-2">
          <table class="table table-bordered table-striped text-center">
            <thead>
              <tr>
                <td colspan="7">
                  <h4 class="text-center text-info m-0">ROOMS IN CART</h4>
                </td>
              </tr>
              <tr>
                <th>ID</th>
                <th>Image</th>
                <th>Room</th>
                <th>Price</th>
                <th>No of Rooms</th>
                <th>Total Price</th>
                <th>
                  <a href="action.php?clear=all" class="badge-danger badge p-1" onclick="return confirm('Are you sure want to clear your cart?');"><i class="fas fa-trash"></i>&nbsp;&nbsp;Clear Cart</a>
                </th>
              </tr>
            </thead>
            <tbody>
              <?php
                require 'db.php';
                $result = mysqli_query($conn,"SELECT * FROM `cart`");
                $grand_total = 0;
  			   while ($row = mysqli_fetch_assoc($result)){
                
              ?>
              <tr>
                <td><?php echo $row['cartID'] ?></td>
                <input type="hidden" class="pid" value="<?php echo $row['cartID'] ?>">
                <td><img src="<?php echo $row['roomImage'] ?>" style="width: 50px;"></td>
                <td><?php echo $row['roomName'] ?></td>
                <td>
                  <i class="fas fa-dollar-sign"></i>&nbsp;&nbsp;<?php echo number_format($row['roomPrice'],2); ?>
                </td>
                <input type="hidden" class="pprice" value="<?php echo $row['roomPrice'] ?>">
                <td>
                  <input type="number" class="form-control itemQty" value="<?php echo $row['qty'] ?>" style="width:75px;">
                </td>
                <td><i class="fas fa-dollar-sign"></i>&nbsp;&nbsp;<?php echo number_format($row['totalPrice'],2); ?></td>
                <td>
                  <a href="action.php?remove=<?php echo $row['cartID'] ?>" class="text-danger lead" onclick="return confirm('Are you sure want to remove this item?');"><i class="fas fa-trash-alt"></i></a>
                </td>
              </tr>
              <?php $grand_total += $row['totalPrice']; ?>
               <?php } mysqli_close($conn); ?>
              <tr>
                <td colspan="3">
                  <a href="reservation.php" class="btn btn-success"><i class="fas fa-cart-plus"></i>&nbsp;&nbsp;Continue
                    Shopping</a>
                </td>
                <td colspan="2"><b>Grand Total</b></td>
                <td><b><i class="fas fa-dollar-sign"></i>&nbsp;&nbsp;<?= number_format($grand_total,2); ?></b></td>
                <td>
                  <a href="checkout.php" class="btn btn-info <?php echo ($grand_total > 1) ? '' : 'disabled'; ?>" style="background: black;"><i class="far fa-credit-card"></i>&nbsp;&nbsp;Checkout</a>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

<!--
    
    <footer style="background: #011b31; padding: 30px; position: fixed; left:0; bottom:0; width:100%;">
        <div class="container" >
           <div class="row" >
               <div class="col-sm-3"> 
        <a href="main.html" class="fmain">HOME</a> <br> 
        <a href="reservation.html" class="fmain">RESERVATION</a>
               </div>
               <div class="col-sm-3">
                   <a class="fmain" href="interior.html" >INTERIOR</a> <br>
                   <a href="#">Bedrooms</a><br>
                   <a href="#">Events Spaces</a> <br>
                   <a href="#">Dining Rooms</a>
               </div>
                  <div class="col-sm-3">
                   <a class="fmain" href="exterior.html" >EXTERIOR</a> <br> 
                   <a href="#">Swimming Pool</a><br>
                   <a href="#">Bar</a> <br>
                   <a href="#">Wedding Halls</a>
               </div>
                 <div class="col-sm-3">
                   <a class="fmain" href="#" >MORE</a> <br> 
                   <a href="#">Resturant</a><br>
                   <a href="contact.html">Contact Us</a> <br>
                   <a href="register.html">Membership</a>
               </div>
           </div>
          <div class="row">
              <div class="col-sm" style="font-size: 1rem; color: white;">
                   Find Us on Social Media
              </div>
          </div>
           <div class="row">
            <div class="col-sm">
                <a href="https://www.facebook.com/AUAfghanistan"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                <a href="https://www.instagram.com/auafofficial/"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                <a href="https://www.linkedin.com/company/auaf/"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                  <a href="https://twitter.com/AUAfghanistan?lang=en"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                  <a href="#" ><i class="fa fa-whatsapp" aria-hidden="true"></i></a>
             </div>
               
           </div>
           <div  style="font-size: 0.8rem; color: white; text-align: center;">
               © 2021 REMOTE LANDS. ALL RIGHTS RESERVED
           </div>

        </div>
    </footer>
     
-->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js'></script>

  <script type="text/javascript">
  $(document).ready(function() {

    // Change the item quantity
    $(".itemQty").on('change', function() {
      var $el = $(this).closest('tr');

      var pid = $el.find(".pid").val();
      var pprice = $el.find(".pprice").val();
      var qty = $el.find(".itemQty").val();
      location.reload(true);
      $.ajax({
        url: 'action.php',
        method: 'post',
        cache: false,
        data: {
          qty: qty,
          pid: pid,
          pprice: pprice
        },
        success: function(response) {
          console.log(response);
        }
      });
    });

    // Load total no.of items added in the cart and display in the navbar
    load_cart_item_number();

    function load_cart_item_number() {
      $.ajax({
        url: 'action.php',
        method: 'get',
        data: {
          cartItem: "cart_item"
        },
        success: function(response) {
          $("#cart-item").html(response);
        }
      });
    }
  });
  </script>
</body>

</html>