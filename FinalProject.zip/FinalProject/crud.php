<?php
// Include config file
session_start();
require_once "db.php";
 
if(isset($_POST['fname'])){ 
// Define variables and initialize with empty values
$fname= $_POST['fname'];
$lname=$_POST['lname'];
$username= $_POST['uname'];
$phone=$_POST['phone'];
$email=$_POST['email'];
$pass=$_POST['password'];




$reg="INSERT INTO `customer`(`fname`, `lname`, `username`, `phone`, `email`, `password`) VALUES ('$fname', '$lname', '$username', '$phone', '$email','$pass')";
	$result = mysqli_query($conn,$reg);
if(!$result){
      echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>An error occured!</strong>
                        </div>';
            
}
else{
      echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>Customer Added Successfully!</strong>
                        </div>';
    header('location:admin.php');
            
}



    // Close connection
    mysqli_close($conn);
}

?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="mt-5">Create Record</h2>
                    <p>Please fill this form and submit to add customer record to the database.</p>
                    <form class="needs-validation" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" name="fname" class="form-control " required pattern="([a-zA-Z]{2,30}\s*)+">
                            <span class="invalid-feedback">Fill out this field as required</span>
                        </div>
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" name="lname" class="form-control "  required pattern= "^[a-zA-Z]{2,30}">
                            <span class="invalid-feedback">Fill out this field as required</span>
                        </div>
                   <div class="form-group">
                            <label>Username</label>
                            <input type="text" name="uname" class="form-control" placeholder="Username" required>
                            <span class="invalid-feedback">Fill out this field as required</span>
                        </div>
                        
                        <div class="form-group">
                            <label>Phone</label>
                            <input type="text" name="phone" class="form-control " required pattern="^\+(?:[0-9]●?){6,14}[0-9]$">
                            <span class="invalid-feedback">Fill out this field as required</span>
                        </div>
                       <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control " required  pattern="[^@]+@[^@]+\.[a-zA-Z]{2,6}">
                            <span class="invalid-feedback">Fill out this field as required</span>
                        </div>
                        
                      <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control " pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,40}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
                            <span class="invalid-feedback">Fill out this field as required</span>
                        </div>
 
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="admin.php" class="btn btn-secondary ml-2">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>