<?php


    session_start();
    require 'db.php';


//	   Remove all items at once from customers
	  if (isset($_GET['clear'])) {
		$dq = "DELETE FROM customer";
		$result = mysqli_query($conn, $dq);
          if(!$result){
              
               echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>Customers exist in feedback and reservation tables!</strong>
                        </div>';
//              echo mysqli_error($conn);
  
          }
              else{
                        echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>All records are removed!</strong>
                        </div>';

	  }

      }

//	   Remove all items at once from reservation
	  if (isset($_GET['clear2'])) {
		$dq = "DELETE FROM reservation";
		$result = mysqli_query($conn, $dq);
          if(!$result){
              
               echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>An error occured!</strong>
                        </div>';
//              echo mysqli_error($conn);
  
          }
              else{
                        echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>All records are removed!</strong>
                        </div>';

	  }

      }

//	   Remove all items at once from feedback
	  if (isset($_GET['clear3'])) {
		$dq = "DELETE FROM feedback";
		$result = mysqli_query($conn, $dq);
          if(!$result){
              
               echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>An error occured!</strong>
                        </div>';
//              echo mysqli_error($conn);
  
          }
              else{
                        echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>All records are removed!</strong>
                        </div>';

	  }

      }



//	   Remove all items at once from contact
	  if (isset($_GET['clear4'])) {
		$dq = "DELETE FROM contact";
		$result = mysqli_query($conn, $dq);
          if(!$result){
              
               echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>An error occured!</strong>
                        </div>';
//              echo mysqli_error($conn);
  
          }
              else{
                        echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>All records are removed!</strong>
                        </div>';

	  }

      }
//	   Remove all items at once from room
	  if (isset($_GET['clear5'])) {
		$dq = "DELETE FROM room";
		$result = mysqli_query($conn, $dq);
          if(!$result){
              
               echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>An error occured!</strong>
                        </div>';
//              echo mysqli_error($conn);
  
          }
              else{
                        echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>All records are removed!</strong>
                        </div>';

	  }

      }

	  // Remove single items from customer
	  if (isset($_GET['remove'])) {
		$id = $_GET['remove'];
  
		$stmt = $conn->prepare('DELETE FROM customer WHERE customerid=?');
		$stmt->bind_param('i',$id);
		$stmt->execute();
          
          if($stmt){
                     echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>Customer Susccessfully removed!</strong>
                        </div>';
              
              		header('location:admin.php');
          }
          else{
                         echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>Delete customer from reservation and feedback first!</strong>
                        </div>';
          }
  
	  }

	  // Remove single items from reservation
	  if (isset($_GET['remove2'])) {
		$id = $_GET['remove2'];
  
		$stmt = $conn->prepare('DELETE FROM reservation WHERE resID=?');
		$stmt->bind_param('i',$id);
		$stmt->execute();
          
          if($stmt){
                     echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>Customer Susccessfully removed!</strong>
                        </div>';
              
              		header('location:admin.php');
          }
          else{
                         echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>Delete customer from reservation and feedback first!</strong>
                        </div>';
          }
  
	  }
	  // Remove single items from feedback
	  if (isset($_GET['remove3'])) {
		$id = $_GET['remove3'];
  
		$stmt = $conn->prepare('DELETE FROM feedback WHERE feedID=?');
		$stmt->bind_param('i',$id);
		$stmt->execute();
          
          if($stmt){
                     echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>Feedback Susccessfully removed!</strong>
                        </div>';
              
              		header('location:admin.php');
          }
          else{
                         echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>Failed!</strong>
                        </div>';
          }
  


	  }

	  // Remove single items from contact
	  if (isset($_GET['remove4'])) {
		$id = $_GET['remove4'];
  
		$stmt = $conn->prepare('DELETE FROM contact WHERE contactID=?');
		$stmt->bind_param('i',$id);
		$stmt->execute();
          
          if($stmt){
                     echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>Message Susccessfully removed!</strong>
                        </div>';
              
              		header('location:admin.php');
          }
          else{
                         echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>Failed!</strong>
                        </div>';
          }

	  }
	  // Remove single items from room
	  if (isset($_GET['remove5'])) {
		$id = $_GET['remove5'];
  
		$stmt = $conn->prepare('DELETE FROM room WHERE id=?');
		$stmt->bind_param('i',$id);
		$stmt->execute();
          
          if($stmt){
                     echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>Room Susccessfully removed!</strong>
                        </div>';
              
              		header('location:admin.php');
          }
          else{
                         echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>Failed!</strong>
                        </div>';
          }

	  }



?>