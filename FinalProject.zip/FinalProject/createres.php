<?php
// Include config file
session_start();
require_once "db.php";
 
if(isset($_POST['uname'])){ 
// Define variables and initialize with empty values

$username= $_POST['uname'];
$pmode=$_POST['pmode'];
$rooms= $_POST['rooms'];
$amount=$_POST['amount'];
$pass=$_POST['password'];
$checkindate=$_POST['checkindate'];
$checkoutdate=$_POST['checkoutdate'];

       $s= "SELECT * FROM `customer` WHERE username= '$username' && password= '$pass'";

        $result= mysqli_query($conn,$s);

        $num= mysqli_num_rows($result);

        if($num== 1){


$reg="INSERT INTO `reservation`(`username`, `pMode`, `rooms`, `amountPaid`,  `password`, `check_in_date`, `check_out_date`) VALUES ('$username', '$pmode', '$rooms', '$amount', '$pass','$checkindate', '$checkoutdate')";
	$result = mysqli_query($conn,$reg);
    
    
if(!$result){
      echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>An error occured!</strong>
                        </div>';
    echo mysqli_error($conn);
            
}
else{
      echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>Reservation Added Successfully!</strong>
                        </div>';
    header('location:admin.php');
            
}
        }
    
    else{
        echo "User does not exist!";
    }



    // Close connection
    mysqli_close($conn);
}

?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="mt-5">Create Reservation</h2>
                    <p>Please fill this form and submit to add a reservation to the database.</p>
                    <form class="needs-validation" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" name="uname" class="form-control " required >
                            <span class="invalid-feedback">Fill out this field as required</span>
                        </div>
                                  <div class="form-group">
                            <select name="pmode" class="form-control">
                              <option value="" selected disabled>-Select Payment Mode-</option>
                              <option value="cod">Cash On Delivery</option>
                              <option value="netbanking">Net Banking</option>
                              <option value="cards">Debit/Credit Card</option>
                            </select>
                          </div>
                           <div class="form-group">
                          <label for="rooms">Room Name</label>
                          <select class="required" class="form-select " id="rooms"  name="rooms">
                         <option selected = "" value="">Select one</option>
                          <?php
                              require"db.php";
                               $result = mysqli_query($conn,"SELECT * FROM `room`");
                              if($result){
                                while ($row = mysqli_fetch_array($result))
                                {
                                      echo '<option value="'. $row['room_name'].'"> '. $row['room_name'] .'</option>';
                                  }
                                  }
                              else{
                                  echo mysqli_error($conn);
                              }
         
                                 mysqli_close($conn);
                                ?>
                                </select>
                            <div class="valid-feedback">Valid.</div>
                            <div class="invalid-feedback">Please select one option.</div>
                        </div>

                        <div class="form-group">
                            <label>Amount Paid</label>
                            <input type="text" name="amount" class="form-control " required >
                            <span class="invalid-feedback">Fill out this field as required</span>
                        </div>
                        
                      <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control " pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,40}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
                            <span class="invalid-feedback">Fill out this field as required</span>
                        </div>
                                  <div class="form-group">
                           <label for="checkindate">Checkin-Date</label>
                            <input type="date" name="checkindate" id="checkindate" class="form-control" required>
                          </div>
                           <label for="checkoutdate">Checkout-Date</label>
                            <div class="form-group">
                            <input type="date" name="checkoutdate" id="checkoutdate" class="form-control" required>
                          </div>
 
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="admin.php" class="btn btn-secondary ml-2">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>