-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 24, 2021 at 06:44 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbhms`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cartID` int(11) NOT NULL,
  `roomName` varchar(100) NOT NULL,
  `roomPrice` varchar(50) NOT NULL,
  `roomImage` varchar(255) NOT NULL,
  `qty` int(10) NOT NULL,
  `totalPrice` varchar(100) NOT NULL,
  `roomCode` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cartID`, `roomName`, `roomPrice`, `roomImage`, `qty`, `totalPrice`, `roomCode`) VALUES
(90, 'CORAL ROOM', '1000', 'Images/room.jpg', 2, '2000', 'R1111'),
(91, 'DIAMOND ROOM', '1000', 'Images/room2.jpg', 2, '2000', 'R2222'),
(92, 'PEARL ROOM', '3000', 'Images/interior2.jpg', 1, '3000', 'R3333'),
(93, 'THREE BEDROOM PALACE', '4000', 'Images/interior.jpg', 1, '4000', 'R4444');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `contactID` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `question` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`contactID`, `name`, `phone`, `email`, `question`) VALUES
(16, 'Manizha Nizami', '+9875345678', 'manizha.nizami@gmail.com', 'Hello,\r\nHow are your prices?\r\n'),
(17, 'Muzhda Noorzad', '+9708967062', 'muzhda.noorzad@gmail.com', 'Hello,\r\nHow are your prices?\r\n'),
(18, 'Fatema Qambary', '+9708967062', 'fatemaqam2@gmail.com', 'Hello,\r\nHow are your prices?\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customerid` int(10) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `phone` varchar(18) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customerid`, `fname`, `lname`, `username`, `phone`, `email`, `password`) VALUES
(68, 'Ali', 'Karimi', 'alikarimi2', '+98634567853', 'alikarimi@gmail.com', 'Mynameisali23'),
(67, 'ayesha', 'durrani', 'ayesha.durrani', '+98764345', 'ayesha.durrani@gmail.com', 'Mynameiskhan234'),
(74, 'Iqbal', 'Karimi', 'iqbalkarimi4', '+93708967062', 'irbal.karimi@gmail.com', 'Iqbal1234'),
(69, 'irfan', 'fazli', 'irfanfazli2', '+9876545678', 'irfanfazli@gmail.com', 'Mynameisirfan23'),
(71, 'Irfan', 'Fazliii', 'irfanfazli4', '+97654345678', 'irfanfazli4@gmail.com', 'Mynameisirfan236'),
(64, 'luqman', 'fazli', 'luqmanfazli2', '+9875345678', 'luqman.fazli@gmail.com', 'Luqman234'),
(66, 'Madina', 'Fazli', 'madina.fazli2', '+93987656788', 'madina.fazli@gmail.com', 'Mynameiskhan23'),
(65, 'madina', 'fazli', 'madinafazli', '+9876456545', 'madina.fazli@gmail.com', 'Mynameiskhan233'),
(63, 'Madina', 'fazli', 'madinafazli2', '+987535686', 'muskanfazlimuskan@gmail.com', 'Mynameiskhan23'),
(62, 'Muzhda', 'Noorzad', 'muzhdanoorzad2', '+9875345678', 'muzhda.noorzad2@gmail.com', 'Mypassword78');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedID` int(10) NOT NULL,
  `answer1` varchar(20) NOT NULL,
  `answer2` varchar(20) NOT NULL,
  `answer3` varchar(20) NOT NULL,
  `comment` varchar(500) DEFAULT NULL,
  `password` varchar(30) NOT NULL,
  `username` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedID`, `answer1`, `answer2`, `answer3`, `comment`, `password`, `username`) VALUES
(8, 'Satisfied', 'Satisfied', 'Satisfied', 'This is a cool hotel.', 'Mynameiskhan23', 'madinafazli2'),
(9, 'Satisfied', 'Satisfied', 'Satisfied', 'This is an amzing hotel.', 'Mynameisirfan23', 'irfanfazli2');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `resID` int(11) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `pMode` varchar(20) NOT NULL,
  `rooms` varchar(255) NOT NULL,
  `amountPaid` varchar(100) NOT NULL,
  `password` varchar(30) NOT NULL,
  `check_in_date` date NOT NULL,
  `check_out_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`resID`, `username`, `pMode`, `rooms`, `amountPaid`, `password`, `check_in_date`, `check_out_date`) VALUES
(6, 'madinafazli2', 'cod', 'CORAL ROOM(1), DIAMOND ROOM(2), THREE BEDROOM PALACE(1), ROYAL KHALEEJ ROOM(1)', '10000', 'Mynameiskhan23', '0000-00-00', '0000-00-00'),
(7, 'madinafazli2', 'cod', 'CORAL ROOM(1), DIAMOND ROOM(2), PEARL ROOM(1), BEDROOM PALACR ROOM(3)', '18000', 'Mynameiskhan23', '0000-00-00', '0000-00-00'),
(8, 'madinafazli', 'cod', 'CORAL ROOM(2), DIAMOND ROOM(3), BEDROOM PALACR ROOM(2)', '13000', 'Mynameiskhan233', '0000-00-00', '0000-00-00'),
(9, 'madina.fazli2', 'cod', 'ROYAL KHALEEJ ROOM(1), CORAL ROOM(1), THREE BEDROOM PALACE(2)', '12000', 'Mynameiskhan23', '0000-00-00', '0000-00-00'),
(10, 'ayesha.durrani', 'netbanking', 'DIAMOND ROOM(3), THREE BEDROOM PALACE(2)', '11000', 'Mynameiskhan234', '0000-00-00', '0000-00-00'),
(11, 'alikarimi2', 'cod', 'CORAL ROOM(1), DIAMOND ROOM(2), ROYAL KHALEEJ ROOM(2)', '9000', 'Mynameisali23', '0000-00-00', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `id` int(11) NOT NULL,
  `room_name` varchar(50) NOT NULL,
  `room_price` varchar(100) NOT NULL,
  `room_qty` int(11) NOT NULL DEFAULT 1,
  `room_image` varchar(255) NOT NULL,
  `room_capacity` varchar(15) NOT NULL,
  `room_availability` varchar(10) NOT NULL,
  `room_code` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`id`, `room_name`, `room_price`, `room_qty`, `room_image`, `room_capacity`, `room_availability`, `room_code`) VALUES
(1, 'CORAL ROOM', '1000', 1, 'Images/room.jpg', '3', 'yes', 'R1111'),
(2, 'DIAMOND ROOM', '1000', 1, 'Images/room2.jpg', '2', 'yes', 'R2222'),
(3, 'PEARL ROOM', '3000', 1, 'Images/interior2.jpg', '3', 'yes', 'R3333'),
(4, 'THREE BEDROOM PALACE', '4000', 1, 'Images/interior.jpg', '5', 'yes', 'R4444'),
(5, 'KHALEEJ SUITE ROOM', '4000', 1, 'Images/room10.jpg', '4', 'yes', 'R5555'),
(6, 'BEDROOM PALACR ROOM', '4000', 1, 'Images/room9.jpg', '5', 'yes', 'R6666'),
(7, 'ROYAL KHALEEJ ROOM', '3000', 1, 'Images/royalKhaleej.jpg', '3', 'yes', 'R7777'),
(8, 'ROYAL LUXURY ROOM', '1000', 1, 'Images/room8.jpg', '2', 'yes', 'R8888'),
(9, 'MEGA THREE-BEDROOM', '3000', 1, 'Images/3bedroom.jpg', '3', 'yes', 'R9999');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cartID`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`contactID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `customerid` (`customerid`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedID`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`resID`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `room_code` (`room_code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cartID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `contactID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customerid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `resID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`username`) REFERENCES `customer` (`username`);

--
-- Constraints for table `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`username`) REFERENCES `customer` (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
