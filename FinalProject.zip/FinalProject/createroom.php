<?php
// Include config file
session_start();
require_once "db.php";
 
if(isset($_POST['rid'])){ 
// Define variables and initialize with empty values
$rid= $_POST['rid'];
$rname=$_POST['rname'];
$rprice= $_POST['rprice'];
$rqty=$_POST['rqty'];
//$rimage=$_POST['rimage'];
$rcap=$_POST['rcapacity'];
$ravail=$_POST['ravailability'];
$rcode=$_POST['rcode'];
				$filename = $_FILES["rimage"]["name"];
				$tempname = $_FILES["rimage"]["tmp_name"];	
				$folder = "image/".$filename;
				$file= addslashes(file_get_contents($_FILES["rimage"]["tmp_name"]));



            $reg="INSERT INTO `room`(`id`, `room_name`, `room_price`, `room_qty`, `room_image`, `room_capacity`, `room_availability`,`room_code`) VALUES ('$rid', '$rname', '$rprice', '$rqty', 'Images/$filename','$rcap', '$ravail', '$rcode')";
	$result = mysqli_query($conn,$reg);
if(!$result){
      echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>An error occured!</strong>
                        </div>';
            
}
else{
      echo '<div class="alert alert-danger alert-dismissible mt-2">
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                          <strong>Room Added Successfully!</strong>
                        </div>';
    header('location:admin.php');
            
}

            




    // Close connection
    mysqli_close($conn);
}

?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="mt-5">Add Room</h2>
                    <p>Please fill this form and submit to add room record to the database.</p>
                    <form class="needs-validation" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label>Room ID</label>
                            <input type="text" name="rid" class="form-control " required placeholder="Room ID">
                            <span class="invalid-feedback">Fill out this field as required</span>
                        </div>
                        <div class="form-group">
                            <label>Room Name</label>
                            <input type="text" name="rname" class="form-control "  placeholder="Room Name" required>
                            <span class="invalid-feedback">Fill out this field as required</span>
                        </div>
                   <div class="form-group">
                            <label>Room Price</label>
                            <input type="price" name="rprice" class="form-control" placeholder="Price" required>
                            <span class="invalid-feedback">Fill out this field as required</span>
                        </div>
                        
                        <div class="form-group">
                            <label>Room Quantity</label>
                            <input type="text" name="rqty" class="form-control " placeholder="Room Quantity">
                            <span class="invalid-feedback">Fill out this field as required</span>
                        </div>
                        <div class="form-group">
                        <label class="form-label" for="rimage">Room Image</label>
                        <input type="file" class="form-control" name="rimage" id="rimage" />
                        </div>
                       <div class="form-group">
                            <label>Room Capacity</label>
                            <input type="text" name="rcapacity" class="form-control " required placeholder = "Room Capacity">
                            <span class="invalid-feedback">Fill out this field as required</span>
                        </div>
                      <div class="form-group">
                            <label>Room Availability</label>
                            <select name="ravailability" class="form-control">
                              <option value="" selected disabled>-Select One-</option>
                              <option value="yes">Yes</option>
                              <option value="no">No</option>
                            </select>
                          </div>
                      <div class="form-group">
                            <label>Room Code</label>
                            <input type="text" name="rcode" class="form-control " placeholder="Room Code" required>
                            <span class="invalid-feedback">Fill out this field as required</span>
                        </div>
 
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="admin.php" class="btn btn-secondary ml-2">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>